/*
PIC 10B 2A, Homework 2
Purpose: Program that records the officers and members of a club, while also taking into account members who hold multiple positions. This is the main file
Author: Lance Anthony Aquino
Date: 04/20/2022
*/


#include "Student.h"
#include "StudentClub.h"
#include <vector>
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;
int main()
{
    // Prompt the user to input the names of all the student officer names. 
    // Duplicate names/Student classes might be created, but this is resolved during the creation of the StudentClub class

    string current_officer_to_add;
    
    cout<< "President: ";
    getline (cin, current_officer_to_add); // prompts the user for the name of the officer to add. Allows spaces
    Student pres = Student (current_officer_to_add); // Creates a Student class for the officer being created
    Student* pres_ptr = &pres; // creates a pointer to the officer being added
    
    cout << "\nVice President: ";
    getline(cin, current_officer_to_add);
    Student v_pres = Student(current_officer_to_add);
    Student* v_pres_ptr = &v_pres;
    
    cout << "\nSecretary: ";
    getline (cin, current_officer_to_add);
    Student sec = Student (current_officer_to_add);
    Student* sec_ptr = &sec;
    
    cout<< "\nTreasurer: ";
    getline (cin,current_officer_to_add);
    Student treas = Student (current_officer_to_add);
    Student* treas_ptr = &treas;
    
    // Prompting the user for the name of the members of the club

    vector<Student*> members;
    std::string name;
    
    while (name != "Q")
    {
        cout << "\nNew Member (Q to quit): "; 
        getline(cin,name); // prompts the user for the name of a new member to add.
        if (name == "Q") // If the user inputs the char "Q", the loop breaks and this is not added to the vector of members
        {
            break;
        }
        Student* new_member = new Student(name);// Dynamically creates a Student class pointer refering to a new member to add. 
        members.push_back(new_member);
    }
    
    StudentClub student_club = StudentClub(pres_ptr, v_pres_ptr , sec_ptr, treas_ptr, members);
    
    size_t listing_width = 16; // setw uses this number, so that all officer positions align
    
    cout<< "MATHLETES (" << " "<<student_club.number_members() << " total members)\n";
    cout <<  setfill(' ')<<setw(listing_width) << "President: ";
    cout<< student_club.get_president() -> get_name()<<'\n';
    cout <<  setfill(' ')<<setw(listing_width) << "Vice President: ";
    cout <<student_club.get_vice_president() -> get_name()<<'\n';
    cout <<  setfill(' ')<<setw(listing_width) << "Secretary: ";
    cout <<student_club.get_secretary() -> get_name()<<'\n';
    cout <<  setfill(' ')<<setw(listing_width) << "Treasurer: ";
    cout<< student_club.get_treasurer() -> get_name()<<'\n';
    

  
    return 0;
    
}

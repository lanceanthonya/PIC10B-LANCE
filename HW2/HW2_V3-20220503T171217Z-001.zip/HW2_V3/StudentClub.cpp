/*
PIC 10B 2A, Homework 2
Purpose: CPP file for StudentClub Class
Author: Lance Anthony Aquino
Date: 04/20/2022
*/

#include "StudentClub.h"
#include <vector>

StudentClub::StudentClub(Student* p, Student* v, Student* s, Student* t, std::vector<Student*> m):
    president(p),
    vice_president (v),
    secretary(s),
    treasurer(t),
    members_of_club(m)
{
    //First, checks if any pointers refer to the same officers but have different addresses. If they do, makes it so that they refer to one address (usually the first address in the list of officers)
    same_officer_check();

    num_students_excluding_officers = members_of_club.size();

    // First, add the officers to the members vector if they aren't in it already. Skips duplicates since the vector is editted in place

    add_officers_to_members();
    
   

    
}

Student* StudentClub::get_president() const
{
    return president;
}


Student* StudentClub::get_vice_president() const
{
    return vice_president;
}


Student* StudentClub::get_secretary() const
{
    return secretary;
}


Student* StudentClub::get_treasurer() const
{
    return treasurer;
}


std::vector<Student*> StudentClub::get_members() const
{
    return members_of_club;
}


void StudentClub::add_member(Student* s)
{
    members_of_club.push_back(s);
}


size_t StudentClub::number_members() const
{
    return members_of_club.size();
}



void StudentClub::same_officer_check()
{
    size_t num_officers = officers_of_club.size();
    for (size_t cur_officer_1 = 0; cur_officer_1 < num_officers ; ++ cur_officer_1) // Iterates through the list of officers once in a primary loop that keeps looking at one officer for the other loop to compare to
    {
        for (size_t cur_officer_2 = 0; cur_officer_2 < num_officers ; ++ cur_officer_2) // Iterates through the list of officers in a secondary loop, comparing each with the officer in the first loop
        {
            if (*officers_of_club[cur_officer_1] == *officers_of_club[cur_officer_2]) // if the officers refer to Student classes of the same name, sets the second officer pointer to the officer in the second loop
            {
                officers_of_club[cur_officer_1] = officers_of_club[cur_officer_2]; 
                break;
            }
        }
    }

    // The vector is editted in place, so the officers should remiain in the same order that they were when the vector was first created. 
    // Sets the officer position pointers to point to the same Student class, only if they refer to the same student
    president = officers_of_club[0];
    vice_president = officers_of_club[1];
    secretary = officers_of_club[2];
    treasurer = officers_of_club[3];
}

void StudentClub::add_officers_to_members(){
    
    for (Student* Current_Officer : officers_of_club) // iterates through the list of officers 
    {
        bool officer_alredy_listed = false;
        for (Student* Current_Member : members_of_club) //iterates throught the members of the club 
        {
            if ((*Current_Officer) == (*Current_Member)) // if the officer's name is found within the list of members, then their name is not added to the list of all members
            {
                officer_alredy_listed = true;
                break;
            }
        }
        if (officer_alredy_listed == false) // if the officer's name was never found in the list, then the pointer to the officer's name is added to the list
        {
            members_of_club.push_back(Current_Officer);
        }
        
        
    }
}

StudentClub::~StudentClub()
{
    
    for (size_t current_member =0 ; current_member < num_students_excluding_officers; ++current_member) // iterates through members that aren't officers, since only the members were dynamically created
    {
        delete members_of_club[current_member]; 
    }
}